@echo off
REM ============================================================
REM  start-meal-planner.bat
REM  One-click launcher for Meal Planner
REM  Owner: Ludek Budinsky
REM
REM  Pure ASCII only (CP1250 / CP852 cmd default safe).
REM  Diacritics in branding are rendered by the React app inside the browser.
REM
REM  Behavior:
REM    1. Resolve APP_ROOT (parent of launchers\) via FOR ~fI
REM    2. Verify dist exists (apps\meal-planner-web\index.html)
REM    3. Verify serve.py exists (..\server\serve.py)
REM    4. Skip start if port 5176 already listening; else start python serve.py
REM    5. Wait up to 10s for port to bind
REM    6. Open Edge --app mode (fallback chain: Edge x86/x64 -> Chrome x64/x86 -> default)
REM ============================================================

setlocal enabledelayedexpansion

REM ---- 1. Resolve APP_ROOT (apps\meal-planner-windows\) ----
for %%I in ("%~dp0..") do set "APP_ROOT=%%~fI"

REM Project root is 2 levels up (out of apps\meal-planner-windows\)
for %%I in ("%APP_ROOT%\..\..") do set "PROJECT_ROOT=%%~fI"

set "DIST_DIR=%PROJECT_ROOT%\apps\meal-planner-web"
set "SERVE_PY=%APP_ROOT%\server\serve.py"
set "URL=http://127.0.0.1:5176/"
set "TITLE=Meal Planner"
set "PORT=5176"

echo ============================================================
echo  %TITLE% (one-click launcher)
echo  PROJECT_ROOT: %PROJECT_ROOT%
echo  DIST_DIR:     %DIST_DIR%
echo  PORT:         %PORT%
echo ============================================================
echo.

REM ---- 2. Verify dist build ----
if not exist "%DIST_DIR%\index.html" (
    echo [FAIL] dist build not found at:
    echo        %DIST_DIR%\index.html
    echo.
    echo To build it:
    echo   cd /d "%PROJECT_ROOT%\meal-planner"
    echo   npm install
    echo   npm run build
    echo.
    pause
    exit /b 2
)

REM ---- 3. Verify serve.py ----
if not exist "%SERVE_PY%" (
    echo [FAIL] serve.py not found at:
    echo        %SERVE_PY%
    pause
    exit /b 2
)

REM ---- 4. Verify Python in PATH ----
where py >nul 2>&1
if !errorlevel! neq 0 (
    where python >nul 2>&1
    if !errorlevel! neq 0 (
        echo [FAIL] Python not in PATH.
        echo        Install Python 3 from https://www.python.org/downloads/
        pause
        exit /b 3
    )
    set "PY=python"
) else (
    set "PY=py -3"
)

REM ---- 5. Server bind check ----
netstat -ano | findstr ":%PORT% " | findstr "LISTENING" >nul
if !errorlevel! equ 0 (
    echo [OK]   Server already listening on %PORT%.
    goto :openbrowser
)

echo [INFO] Starting server on port %PORT% via %PY% serve.py ...
start "%TITLE% server" /MIN %PY% "%SERVE_PY%"

REM Wait up to 10 seconds for server to bind (5 attempts x 2s)
set /a "attempts=0"
:waitloop
ping -n 2 127.0.0.1 >nul
netstat -ano | findstr ":%PORT% " | findstr "LISTENING" >nul
if !errorlevel! equ 0 goto :openbrowser
set /a "attempts+=1"
if !attempts! lss 5 goto :waitloop
echo [WARN] Server did not bind within 10 s. Opening browser anyway.

:openbrowser
echo [INFO] Opening %URL% ...
echo.

REM ---- 6. Browser fallback chain ----
set "EDGE_X86=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
set "EDGE_X64=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
set "CHROME_X86=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
set "CHROME_X64=%ProgramFiles%\Google\Chrome\Application\chrome.exe"

if exist "%EDGE_X86%" (
    start "" "%EDGE_X86%" --app=%URL%
    goto :done
)
if exist "%EDGE_X64%" (
    start "" "%EDGE_X64%" --app=%URL%
    goto :done
)
if exist "%CHROME_X64%" (
    start "" "%CHROME_X64%" --app=%URL%
    goto :done
)
if exist "%CHROME_X86%" (
    start "" "%CHROME_X86%" --app=%URL%
    goto :done
)

echo [INFO] Edge/Chrome not found, using default browser.
start "" %URL%

:done
endlocal
exit /b 0
