@echo off
REM  Meal Planner - jednoklick spoustec
REM  Spustit tento soubor primo z extrahovaneho adresare.
start "" "%~dp0apps\meal-planner-windows\launchers\start-meal-planner.bat"
