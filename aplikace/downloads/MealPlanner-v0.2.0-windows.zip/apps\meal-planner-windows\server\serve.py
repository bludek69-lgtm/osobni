#!/usr/bin/env python3
r"""
Minimal HTTP server for Meal Planner Windows one-click launcher.

Serves the Vite-built SPA from ../../meal-planner-web/ on 127.0.0.1:5176.

Endpoints:
  /api/health                    -> JSON {version, now}
  /assets/*                      -> dist/assets/ (Vite hashed bundles)
  /favicon.ico /manifest.webmanifest /icons/* /sw.js /workbox-*.js /registerSW.js
                                 -> served verbatim from dist
  anything else                  -> dist/index.html (SPA fallback for HashRouter
                                    safety - HashRouter only uses /, but any
                                    accidental deep-link still returns the app
                                    shell instead of 404)

Design rules followed:
  - Pure ASCII source; raw-string docstring (r-prefix) handles backslashes
  - 127.0.0.1 bind only (no LAN exposure)
  - No external dependencies beyond Python 3 standard library
  - Mountable on top of existing apps/meal-planner-web/ build output
"""

import json
import sys
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

# ---- Paths (absolute, derived from this file's location) ----
SCRIPT_DIR   = Path(__file__).resolve().parent             # apps\meal-planner-windows\server
WIN_APP_DIR  = SCRIPT_DIR.parent                           # apps\meal-planner-windows
APPS_DIR     = WIN_APP_DIR.parent                          # apps
DIST_DIR     = APPS_DIR / "meal-planner-web"               # the Vite build output

HOST = "127.0.0.1"
PORT = 5176
VERSION = "meal-planner-windows-launcher v0.1.0"
OWNER = "Ludek Budinsky"  # ASCII fallback for stdout; UI strings use diacritics

MIME = {
    ".html":         "text/html; charset=utf-8",
    ".js":           "application/javascript; charset=utf-8",
    ".mjs":          "application/javascript; charset=utf-8",
    ".css":          "text/css; charset=utf-8",
    ".json":         "application/json; charset=utf-8",
    ".webmanifest":  "application/manifest+json; charset=utf-8",
    ".svg":          "image/svg+xml",
    ".png":          "image/png",
    ".jpg":          "image/jpeg",
    ".ico":          "image/x-icon",
    ".woff":         "font/woff",
    ".woff2":        "font/woff2",
    ".map":          "application/json",
}


def mime_for(path: Path) -> str:
    return MIME.get(path.suffix.lower(), "application/octet-stream")


class Handler(BaseHTTPRequestHandler):

    def log_message(self, fmt, *args):
        # Silence default access log (one-click app, terminal stays clean)
        return

    def _json(self, code: int, body: dict):
        data = json.dumps(body, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _serve_file(self, path: Path):
        try:
            data = path.read_bytes()
        except (FileNotFoundError, IsADirectoryError):
            self.send_error(404, f"Not found: {path.name}")
            return
        self.send_response(200)
        self.send_header("Content-Type", mime_for(path))
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        path = self.path.split("?")[0]

        # 1) /api/* endpoints
        if path == "/api/health":
            self._json(200, {
                "version": VERSION,
                "owner":   OWNER,
                "now":     datetime.now(timezone.utc).isoformat(),
                "dist":    str(DIST_DIR),
                "port":    PORT,
            })
            return
        if path.startswith("/api/"):
            self._json(404, {"ok": False, "message": f"unknown endpoint: {path}"})
            return

        # 2) Static root files served verbatim from dist
        rooted = {
            "/favicon.ico",
            "/manifest.webmanifest",
            "/registerSW.js",
            "/sw.js",
        }
        if path in rooted or path.startswith("/icons/") or path.startswith("/workbox-") or path.startswith("/assets/"):
            # Reject path-traversal attempts
            if ".." in path:
                self.send_error(400, "Bad path")
                return
            target = DIST_DIR / path.lstrip("/")
            self._serve_file(target)
            return

        # 3) SPA fallback - return index.html for any other path
        #    HashRouter only uses '/', but this also covers accidental deep
        #    links and bookmarks pointing to /jidelnicek (without #).
        index = DIST_DIR / "index.html"
        self._serve_file(index)


def main() -> int:
    if not DIST_DIR.is_dir():
        print(f"[FAIL] dist dir not found: {DIST_DIR}", file=sys.stderr)
        print(f"        Run: cd .MealPlanner\\meal-planner && npm install && npm run build",
              file=sys.stderr)
        return 2
    if not (DIST_DIR / "index.html").is_file():
        print(f"[FAIL] index.html missing in dist: {DIST_DIR}", file=sys.stderr)
        return 2

    print(f"[OK] {VERSION}")
    print(f"     listening on http://{HOST}:{PORT}/")
    print(f"     dist: {DIST_DIR}")
    print(f"     owner: {OWNER}")
    print(f"     (Ctrl+C to stop)")
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n[INFO] Shutdown requested")
        server.server_close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
